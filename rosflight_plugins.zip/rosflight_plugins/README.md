ROSflight Plugins
=================

This ROS package contains basic Gazebo plugins for MAVs in simulation.
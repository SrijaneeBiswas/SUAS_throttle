#!/usr/bin/env python

# This code is for implementing autopilot for fixed-wing model on Gazebo and hardware. The aerodynamic coefficients and all other associated constants for the simulation model are obtained by launching the Gazebo model. For hardware, we'll start with the gains for Bixler model.


import rospy
import rospkg
import time
import numpy 		 as np
import scipy.linalg 	 as la
import numpy.linalg 	 as lalg
import cv2
import math
from math 		 import *
from sensor_msgs.msg	 import Image
from numpy 		 import sin, cos, tan
from std_msgs.msg 	 import String
from geometry_msgs.msg 	 import Twist

from rosplane_msgs.msg import Command
from rosplane_msgs.msg import State
from rosplane_msgs.msg import Param
from rosplane_msgs.msg import follow_out
from rosplane_msgs.msg import Estimation

Va_c  = 35.0
h_c   = 0
chi_c = 0
#phi_c = 30*np.pi/180

########## Initialization #############

pn = 0
pe = 0
h  = 0

Va    = 0
phi   = 0
theta = 0
chi   = 0

p = 0
q = 0
r = 0

kp_phi     = 0
kd_phi     = 0
kp_chi     = 0
ki_chi     = 0
kp_theta   = 0
kd_theta   = 0
k_theta_dc = 0

ki_h  = 0
kp_h  = 0
kp_V2 = 0
ki_V2 = 0
kp_V  = 0
ki_V  = 0

h_take_off = 0
h_hold     = 0
theta_to   = 0

delta_a_max   = 0
phi_max       = 0
delta_e_max   = 0
sampling_time = 0
out           = 0
Ts            = 0

delta_a       = 0
delta_e       = 0
delta_t       = 0

error_roll    = 0
error_pitch   = 0
i_chi         = 0
error_chi     = 0
i_h           = 0
error_h       = 0
i_Va1         = 0
error_Va1     = 0
i_Va2         = 0
error_Va2     = 0
i_roll        = 0

######### Subscriber function to true states ##############

def callback(data):
    
    global pn1, pe1, h1, Va1, phi, theta, chi1, p1, q1, r1
    global phi, theta
    pn1    = data.position[0]
    pe1    = data.position[1]
    pd    = data.position[2]

    h1     = -data.position[2]
    
    #print 'true', pn, pe, h

    Va1    = data.Va
    phi   = data.phi
    theta = data.theta
    chi1   = data.chi

    p1     = data.p
    q1     = data.q
    r1     = data.r

####### Subscriber function to estimated states #######

def callback4(data4):

   global pn, pe, h, Va, chi, p, q, r

   pn = data4.pnhat
   pe = data4.pehat
   h  = data4.hhat

   print pn, pe, h

   Va  = data4.Vahat
   chi = data4.chihat
   p   = data4.phat
   q   = data4.qhat
   r   = data4.rhat

########## Subscriber function to commands ################

def callback3(data3):

    global chi_c, h_c, Va_c

    chi_c = data3.chi_c
    h_c   = data3.h_c
    Va_c  = 35

    #return chi_c, h_c, Va_c

########## Subscriber function to parameters ##############

def callback2(data2):
    
    global delta_a_max, phi_max, delta_e_max, sampling_time
    global delta_a, error_roll, delta_e, error_pitch, i_chi, error_chi, i_h, error_h, i_Va1, error_Va1, i_Va2, error_Va2
    global err1, err2, i_roll, err3, error
    global delta_a, delta_e, delta_t

    
    delta_a_max = data2.delta_a_max
    phi_max     = data2.phi_max
    delta_e_max = data2.delta_e_max
    
    Ts          = data2.sampling_time

    # Course Hold
    err1      = chi_c - chi
    error_chi = err1
    #while err1 >= np.pi:
    #    err1 = err1 - 2*np.pi
    #while err1 < -np.pi:
    #    err1 = err1 + 2*np.pi

    i_chi     = i_chi + (Ts/2)*(err1 - error_chi)
    up_chi    = 1.0*err1
    ui_chi    = 0*i_chi
    #if abs(error) > np.divide(15*np.pi, 180):
        #i_chi = 0   
    phi_c = up_chi + ui_chi

    while phi_c >= np.pi:
        phi_c = phi_c - 2*np.pi
    while phi_c < -np.pi:
        phi_c = phi_c + 2*np.pi

    #print chi_c, chi


    if phi_c > 0.8: 
        phi_c = 0.8
    elif phi_c < -0.8:
        phi_c = -0.8
    else:
        phi_c = phi_c
    

    # Roll Hold
    err2       = phi_c - phi
    error_roll = err2
    i_roll     = i_roll + (Ts/2)*(err2 - error_roll)

    up      = 1.17/1.5*err2 #0.7
    ud      = -0.013*p
    delta_a = up + ud

    if delta_a > 0.6:
        delta_a = 0.6
    elif delta_a < -0.6:
        delta_a = -0.6
    else:
        delta_a = delta_a


    # Altitude Hold
    err3      = h_c + h
    i_h       = i_h + (Ts/2)*(err3 - error_h)
    error_h   = err3
    up_h      = 3.0*err3 #0.2
    ui_h      = 0.01*i_h

    theta_c = (up_h + ui_h)   


#    while theta_c >= np.pi:
#        theta_c = theta_c- 2*np.pi
#    while theta_c < -np.pi:
#        theta_c = theta_c + 2*np.pi

    if theta_c > (45*np.pi/180):
        theta_c = (45*np.pi/180)
    elif theta_c < -(45*np.pi/180):
        theta_c = -(45*np.pi/180)
    else:
        theta_c = theta_c

    # Pitch Hold
    err4        = theta_c - theta
    error_pitch = err4
    up_th       = 0.07*err4
    ud_th       = -0.017*q

    delta_e     = up_th +  ud_th

    if delta_e > delta_e_max:
        delta_e = delta_e_max
    elif delta_e < -delta_e_max:
        delta_e = -delta_e_max
    else:
        delta_e = delta_e


    # Airspeed Hold using Throttle
    error    = Va_c - Va
    error_Va2= error
    i_Va2    = i_Va2 + (Ts/2)*(error - error_Va2)
    
    up_Va2       = 0.7*error
    ui_Va2       = 0.7*i_Va2

    if up_Va2+ui_Va2 > 2:
        delta_t = 2
    elif up_Va2+ui_Va2 < 0.0:
        delta_t = 0.0
    else:
        delta_t = up_Va2+ui_Va2

    return delta_a, delta_e, delta_t


def main():

    
    # Initialize the current node and publishing rate
    rospy.init_node('autopilot', anonymous=True)
    r1 = rospy.Rate(50)

    # Define the subscriber. Change topic name here while using this for hardware. The readings will come from different sensors.
    rospy.Subscriber('/fixedwing/truth', State, callback)
    rospy.Subscriber('/param_uav', Param, callback2)
    rospy.Subscriber('/follow_out', follow_out, callback3)
    rospy.Subscriber('/est_states', Estimation, callback4)

    # Define the publisher
    pub = rospy.Publisher('/fixedwing/command', Command, queue_size = 10)
    pub2 = rospy.Publisher('/command', Command, queue_size=10)

    while not rospy.is_shutdown():
        cmd = Command()

        cmd.x  = delta_a
        cmd.y  = delta_e
        #cmd.z = theta_c
        cmd.F  = delta_t

        cmd2 = Command()

        cmd2.x  = delta_a
        cmd2.y  = delta_e
        cmd2.F   = 0

        #print cmd.x, cmd2.x
        
        pub2.publish(cmd2)
        pub.publish(cmd)
        r1.sleep()

    rospy.loginfo("Shutting down in main")
    rospy.signal_shutdown(0)

if __name__ == "__main__":
	main()  

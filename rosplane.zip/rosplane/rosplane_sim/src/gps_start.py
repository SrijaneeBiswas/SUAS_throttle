#!/usr/bin/env python

import rospy
import rospkg 
import numpy as np
import scipy.linalg as la
import utm
import math
from math import * 
from std_msgs.msg import String

from rosflight_msgs.msg import GPS

total = 0
sum_pe = 0
sum_pn = 0

pe_init = 0
pn_init = 0

def start_loc(data):

    global total, sum_pn, sum_pe
    global pn_init, pe_init

    pn_lat = data.latitude
    pe_lon = data.longitude
    a      = utm.from_latlon(pn_lat, pe_lon)

    total   += 1
    sum_pe  += a[0]
    sum_pn  += a[1]

    pe_init = sum_pe/total
    pn_init = sum_pn/total

    print pe_init, pn_init

    return pe_init, pn_init

def main():

    rospy.init_node('gps_start', anonymous=True)
    r1 = rospy.Rate(1)

    rospy.Subscriber('/fixedwing/gps', GPS, start_loc)

    while not rospy.is_shutdown():

        r1.sleep()

    rospy.loginfo("Shutting down in main")
    rospy.signal_shutdown(0)

if __name__ == "__main__":
	main()  

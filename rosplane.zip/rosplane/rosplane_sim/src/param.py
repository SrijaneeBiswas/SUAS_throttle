#!/usr/bin/env python

# This code is analogous to param.m in MATLAB. It calculates and publishes all the PID gains, which are subscribed by the autopilot node.


import rospy
import rospkg
import time
import numpy 		 as np
import scipy.linalg 	 as la
import numpy.linalg 	 as lalg
import cv2
from math 		 import *
from sensor_msgs.msg	 import Image
from numpy 		 import sin, cos, tan
from std_msgs.msg 	 import String
from geometry_msgs.msg 	 import Twist

from rosplane_msgs.msg import Param

###### Initializing constant terms from param.m ###########

mass     = 3.92
gravity  = 9.8

Jx       = 0.213
Jxz      = 0.04
Jy       = 0.171
Jz       = 0.35

S_wing   = 0.468
b        = 1.8
c        = 0.26
C_prop   = 1.0
S_prop   = 0.0314
rho      = 1.2682

k_Omega  = 0.0
k_T_P    = 0.0
k_motor  = 30.0
e        = 0.8

Va0      = 16.38
delta_e0 = 0.02967
delta_t0 = 0.4

phi0     = 0
theta0   = 0.0349
psi0     = 0
alpha0   = 0.3040363557

M        = 50
epsilon  = 0.1592

gamma    = Jx*Jz - np.power(Jxz, 2)
gamma1   = np.divide(Jxz*(Jx-Jy+Jz), gamma)
gamma2   = np.divide(Jz*(Jz-Jy)+np.power(Jxz,2), gamma)
gamma3   = np.divide(Jz, gamma)
gamma4   = np.divide(Jxz, gamma)
gamma5   = np.divide(Jz-Jx, Jy)
gamma6   = np.divide(Jxz, Jy)
gamma7   = np.divide((Jx-Jy)*Jx+np.power(Jxz,2), gamma)
gamma8   = np.divide(Jx, gamma)

acc_bias_range           = 0.6
acc_bias_walk_stdev      = 1e-05
acc_stdev                = 0.19
airspeed_bias_range      = 0.15
airspeed_bias_walk_stdev = 0.001
airspeed_stdev           = 1.15
baro_bias_range          = 500
baro_bias_walk_stdev     = 0.1
baro_stdev               = 4.0

gyro_bias_range          = 0.25
gyro_bias_walk_stdev     = 1e-05
gyro_stdev               = 0.02

altitude_take_off_zone   = 10
altitude_hold_zone       = 35
theta_take_off           = np.divide(30*np.pi, 180)

sampling_time            = 0.01

###### Initializing aerodynamic coefficients for Gazebo model ###########

C_L_0       = 0.2869
C_L_alpha   = 5.1378
#C_L_q       = 0.0
C_L_beta    = 0.0
C_L_delta_a = 0.0
C_L_delta_e = 0.5202
C_L_delta_r = 0.0
C_L_p       = 0.0
C_L_q       = 1.7102
C_L_r       = 0.0

C_D_0       = 0.03087
C_D_alpha   = 0.0043021
C_D_beta    = 0.0
C_D_delta_a = 0.0
C_D_delta_e = 0.01879
C_D_delta_r = 0.0
C_D_p       = 0.02815
C_D_q       = 0.2514
C_D_r       = 0.0

C_m_0       = 0.0362
C_m_alpha   = -0.2627
C_m_beta    = 0.0
C_m_delta_a = 0.0
C_m_delta_e = -1.2392
C_m_delta_r = 0.0
C_m_p       = 0.0
C_m_q       = -9.7213
C_m_r       = 0.0

C_Y_0       = 0.0
C_Y_alpha   = 0.0
C_Y_beta    = -0.2471
C_Y_delta_a = -0.02344
C_Y_delta_e = 0.0
C_Y_delta_r = 0.1591
C_Y_p       = -0.07278
C_Y_q       = 0.0
C_Y_r       = 0.1849

C_ell_0       = 0.0
C_ell_alpha   = 0.0
C_ell_beta    = 0.0193
C_ell_delta_a = 0.2818
C_ell_delta_e = 0.0
C_ell_delta_r = 0.00096
C_ell_p       = -0.5406
C_ell_q       = 0.0
C_ell_r       = 0.1929

C_n_0       = 0.0
C_n_alpha   = 0.0
C_n_beta    = 0.08557
C_n_delta_a = 0.0095
C_n_delta_e = 0.0
C_n_delta_r = -0.06
C_n_p       = -0.0498
C_n_q       = 0.0
C_n_r       = -0.0572

C_p_0       = gamma3*C_ell_0 + gamma4*C_n_0
C_p_beta    = gamma3*C_ell_beta + gamma4*C_n_beta
C_p_p       = gamma3*C_ell_p + gamma4*C_n_p
C_p_r       = gamma3*C_ell_r + gamma4*C_n_r
C_p_delta_a = gamma3*C_ell_delta_a + gamma4*C_n_delta_a
C_p_delta_r = gamma3*C_ell_delta_r + gamma4*C_n_delta_r

C_r_0       = gamma4*C_ell_0 + gamma8*C_n_0
C_r_beta    = gamma4*C_ell_beta + gamma8*C_n_beta
C_r_p       = gamma4*C_ell_p + gamma8*C_n_p
C_r_r       = gamma4*C_ell_r + gamma8*C_n_r
C_r_delta_a = gamma4*C_ell_delta_a + gamma8*C_n_delta_a
C_r_delta_r = gamma4*C_ell_delta_r + gamma8*C_n_delta_r

###### Initializing variable for the autopilot loops ###########

phi_max     = 30*np.pi/180
e_phi_max   = 25*np.pi/180
delta_a_max = 45*np.pi/180
zeta_phi    = 0.7

Va            = 10
bandwidth_chi = 80
chi_max       = 10*np.pi/180
zeta_chi      = 10

beta_max    = 5*np.pi/180
e_beta_max  = 10*np.pi/180
delta_r_max = 40*np.pi/180
zeta_beta   = 0.9

theta_max     = 10*np.pi/180
e_theta_max   = 10*np.pi/180
delta_e_max   = 45*np.pi/180
zeta_theta    = 1

bandwidth_h = 25
zeta_h      = 0.9
max_height  = 5

bandwidth_V2 = 8
zeta_V2      = 2.5

omega_n_V = 0.8
zeta_V    = 0.8


####### Calculating TF constants ############

# ---------- constants for lateral TFs ----------
const1    = 0.5*rho*np.power(Va0, 2)*S_wing*b
const2    = np.divide(0.5*b, Va0)

# ---------- constants for sideslip TF ----------
const3    = 0.5*rho*Va0*S_wing/mass

# ---------- constants for longitudinal TFs -------
const4    = np.divide(0.5*rho*np.power(Va0, 2)*c*S_wing, Jy)

a_phi1    = -const1*C_p_p*const2
a_phi2    = const1*C_p_delta_a

a_beta1   = -const3*C_Y_beta
a_beta2   = const3*C_Y_delta_r

a_theta1  = np.divide(const4*C_m_q*0.5*c, Va0)
a_theta2  = -const4*C_m_alpha
a_theta3  = const4*C_m_delta_e

temp1     = rho*Va0*S_wing*(C_D_0+C_D_alpha*alpha0+C_D_delta_e*delta_e0)
a_V1      = np.divide(temp1, mass) + np.divide(rho*S_prop*C_prop*Va0, mass)
a_V2      = rho*S_prop*C_prop*np.power(k_motor, 2)*delta_t0
a_V3      = gravity*cos(theta0-psi0)


############## Main function #####################

def main():

    # Initialize the current node and publishing rate
    rospy.init_node('param', anonymous=True)
    r1 = rospy.Rate(50)

    # Define publisher
    pub = rospy.Publisher('/param_uav', Param, queue_size = 10)

    while not rospy.is_shutdown():

        # Roll Hold Loop
        kp_phi      = np.divide(delta_a_max*np.sign(a_phi2), e_phi_max)
        omega_n_phi = np.power(np.divide(abs(a_phi2)*delta_a_max, e_phi_max), 0.5)
        kd_phi      = np.divide((2*zeta_phi*omega_n_phi - a_phi1), a_phi2)

        # Course Hold Loop
        omega_n_chi   = np.divide(omega_n_phi, bandwidth_chi)
        kp_chi        = np.divide(2*zeta_chi*omega_n_chi*Va, gravity)
        ki_chi        = np.divide(np.power(omega_n_chi, 2)*Va, gravity)

        # Pitch Hold Loop
        kp_theta      = np.divide(delta_e_max*np.sign(a_theta3), e_theta_max)
        omega_n_theta = np.power(np.divide(a_theta2 + (delta_e_max*abs(a_theta3)), e_theta_max), 0.5)
        kd_theta      = np.divide((2*zeta_theta*omega_n_theta - a_theta1), a_theta3)
        k_theta_dc    = np.divide((kp_theta*a_theta3), (a_theta2+kp_theta*a_theta3))

        # Altitude Hold using Commanded Pitch
        omega_n_h     = np.divide(omega_n_theta, bandwidth_h)
        ki_h          = np.divide(np.power(omega_n_h, 2), k_theta_dc*Va0)
        kp_h          = np.divide((2*zeta_h*omega_n_h), k_theta_dc*Va0)

        # Airspeed Hold using Commanded Pitch
        omega_n_V2    = np.divide(omega_n_theta, bandwidth_V2)
        kp_V2         = np.divide((a_V1 - 2*zeta_V2*omega_n_V2), k_theta_dc*gravity)
        ki_V2         = np.divide(-np.power(omega_n_V2, 2), (k_theta_dc*gravity))

        # Airspeed Hold using Throttle
        kp_V          = np.divide((2*zeta_V*omega_n_V - a_V1), a_V2)
        ki_V          = np.divide(np.power(omega_n_V, 2),a_V2)

        params = Param()

        params.kp_phi                 = kp_phi
        params.kd_phi                 = kd_phi
        params.kp_chi                 = kp_chi
        params.ki_chi                 = ki_chi
        params.kp_theta               = kp_theta
        params.kd_theta               = kd_theta
        params.k_theta_dc             = k_theta_dc
        params.ki_h                   = ki_h
        params.kp_h                   = kp_h
        params.kp_V2                  = kp_V2
        params.kp_V                   = kp_V
        params.ki_V                   = ki_V
        params.altitude_take_off_zone = altitude_take_off_zone
        params.altitude_hold_zone     = altitude_hold_zone
        params.theta_take_off         = theta_take_off
        params.delta_a_max            = delta_a_max
        params.phi_max                = phi_max
        params.delta_e_max            = delta_e_max
        params.sampling_time          = sampling_time
 
        pub.publish(params)
        r1.sleep()

    rospy.loginfo("Shutting down in main")
    rospy.signal_shutdown(0)

if __name__ == "__main__":
	main()  

#!/usr/bin/env python


import rospy
import rospkg 
import numpy as np
import scipy.linalg as la
import utm
import math
from math import * 
from std_msgs.msg import String

from rosflight_msgs.msg import GPS    # ROS message that generates latitude,longitude GPS data
from rosplane_msgs.msg import GPS_loc # custom message for calculating pn, pe wrt starting location
pn = 0
pe = 0

vg  = 0
chi = 0

start_pn = 4457622.36605
start_pe = 445956.318382

def callback(data):

    global pn, pe, vg, chi

    pn_lat = data.latitude
    pe_lon = data.longitude
  
    vg     = data.speed
    chi    = data.ground_course

    if math.isnan(vg) or vg == 0:
        vg = 0.01
    if math.isnan(chi):
        chi = 0.01

    chi    = np.deg2rad(chi)

    #while ((math.fabs(chi) - math.pi) > 0.001): # handles both directions, with a bit of error
    #    if (chi > pi):
    #        chi = chi - 2*math.pi;
    #    if (chi < -pi):
    #        chi = chi + 2*math.pi;
    while chi > np.pi:
        chi = chi - 2*np.pi
    while chi <= -np.pi:
        chi = chi + 2*np.pi

    a  = utm.from_latlon(pn_lat, pe_lon)
    pe_curr = a[0]
    pn_curr = a[1]

    pn = pn_curr - start_pn
    pe = pe_curr - start_pe


    return pn, pe, vg, chi

def main():

    # Initialize the current node and publishing rate
    rospy.init_node('estimation', anonymous=True)
    r1 = rospy.Rate(10)

    rospy.Subscriber('/fixedwing/gps', GPS, callback)
    
    pub = rospy.Publisher('/gps_loc', GPS_loc, queue_size=10)

    while not rospy.is_shutdown():

        mav_loc = GPS_loc()
        mav_loc.pn = pn
        mav_loc.pe = pe
        mav_loc.vg = vg
        mav_loc.chi = chi

        pub.publish(mav_loc)
        r1.sleep()

    rospy.loginfo("Shutting down in main")
    rospy.signal_shutdown(0)

if __name__ == "__main__":
	main()  

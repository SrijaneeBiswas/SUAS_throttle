#!/usr/bin/env python
# Software License Agreement (BSD License)
#

import rospy
import rospkg 
import numpy as np
import scipy.linalg as la
import utm

from math import * 
from std_msgs.msg import String

from rosflight_msgs.msg import Airspeed
from rosflight_msgs.msg import GPS
from rosflight_msgs.msg import Barometer
from rosplane_msgs.msg import Estimation
from sensor_msgs.msg import Imu

T=1.0/100.0
a=150
alpha_lpf = np.exp(-T*a)

# Initializing variables

x_gyro_lpf  = 0
y_gyro_lpf  = 0
z_gyro_lpf  = 0

phi_num = 0
phi_den = 0
theta_num = 0

phat = 0
qhat = 0
rhat = 0

y_diff_press_lpf = 0
Vahat            = 0

y_gps_n_lpf      = 0
y_gps_e_lpf      = 0
pnhat            = 0
pehat            = 0

y_gps_chi_lpf    = 0
y_gps_vg_lpf     = 0
chihat           = 0
vghat            = 0

y_static_press_lpf = 0
hhat              = 0

phihat   = 0
thetahat = 0
wnhat    = 0
wehat    = 0
psihat   = 0

flag     = 0
gravity  = 9.8
rho      = 1.2682
pn_init  = 0
pe_init  = 0

###### Callback function to /fixedwing/imu/data topic #########

def callback(data): 

    global x_gyro_lpf, y_gyro_lpf, z_gyro_lpf
    global phat, qhat, rhat, phihat, thetahat
    
    x_accel    = data.linear_acceleration.x
    y_accel    = data.linear_acceleration.y
    z_accel    = data.linear_acceleration.z
    x_gyro     = data.angular_velocity.x
    y_gyro     = data.angular_velocity.y
    z_gyro     = data.angular_velocity.z
    print alpha_lpf  
    x_gyro_lpf  = alpha_lpf*x_gyro_lpf  + (1-alpha_lpf)*x_gyro
    y_gyro_lpf  = alpha_lpf*y_gyro_lpf  + (1-alpha_lpf)*y_gyro
    z_gyro_lpf  = alpha_lpf*z_gyro_lpf  + (1-alpha_lpf)*z_gyro
   
    phi_num     = alpha_lpf*phihat + (1-alpha_lpf)*y_accel
    phi_den     = alpha_lpf*phihat + (1-alpha_lpf)*z_accel
    theta_num   = alpha_lpf*thetahat + (1-alpha_lpf)*x_accel

    phihat      = np.arctan2(phi_num,phi_den)
    thetahat    = np.arcsin(theta_num/gravity)

    phat        = x_gyro_lpf
    qhat        = y_gyro_lpf
    rhat        = z_gyro_lpf

    return phat, qhat, rhat, phihat, thetahat


###### Callback function to /fixedwing/airspeed topic #########

def callback2(data2):

    global y_diff_press_lpf
    global Vahat

    Va         = data2.velocity
    diff_press = data2.differential_pressure
    temp       = data2.temperature

    #y_diff_press_lpf = alpha_lpf*y_diff_press_lpf + (1-alpha_lpf)*diff_press
    #Vahat            = np.sqrt((2/rho)*y_diff_press_lpf)
    Vahat = alpha_lpf*Vahat + (1-alpha_lpf)*Va

    return Vahat


###### Callback function to /fixedwing/gps topic ##############

def callback3(data3):

    global y_gps_n_lpf, y_gps_e_lpf, y_gps_chi_lpf, y_gps_vg_lpf
    global pnhat, pehat, chihat, vghat
    global flag, pn_init, pe_init

    pn_lat  = data3.latitude
    pe_lon  = data3.longitude
    pd      = data3.altitude
    Vg      = data3.speed
    chi     = data3.ground_course

    a  = utm.from_latlon(pn_lat, pe_lon)
    pe = a[0]
    pn = a[1]

    print flag
    if flag == 0:
        pn_init = pn
        pe_init = pe
        flag    = flag + 1
    else:
        pn      = pn - pn_init
        pe      = pe - pe_init
        flag    = flag + 1

    y_gps_n_lpf   = alpha_lpf*y_gps_n_lpf + (1-alpha_lpf)*pn
    y_gps_e_lpf   = alpha_lpf*y_gps_e_lpf + (1-alpha_lpf)*pe

    y_gps_chi_lpf = alpha_lpf*y_gps_chi_lpf + (1-alpha_lpf)*chi
    y_gps_vg_lpf  = alpha_lpf*y_gps_vg_lpf  + (1-alpha_lpf)*Vg

    pnhat  = y_gps_n_lpf
    pehat  = y_gps_e_lpf

    chihat = y_gps_chi_lpf
    vghat  = y_gps_vg_lpf

    return pnhat, pehat, chihat, vghat

##### Callback function to /fixedwing/baro topic #########

def callback4(data4):

    global y_static_press_lpf
    global hhat

    pd           = data4.altitude
    static_press = data4.pressure

    #y_static_press_lpf = alpha_lpf*y_static_press_lpf + (1-alpha_lpf)*static_press
    #hhat               = y_static_press_lpf/(rho*gravity)

    hhat = alpha_lpf*hhat + (1-alpha_lpf)*(-pd)

    return hhat
  

###### Calling Main function #############

def main():

    # Initialize the current node and publishing rate
    rospy.init_node('estimation', anonymous=True)
    r1 = rospy.Rate(10)

    # Define subscribers to the different sensors
    rospy.Subscriber('/fixedwing/imu/data', Imu, callback)
    rospy.Subscriber('/fixedwing/airspeed', Airspeed, callback2)
    rospy.Subscriber('/fixedwing/gps', GPS, callback3)
    rospy.Subscriber('/fixedwing/baro', Barometer, callback4)

    # Define the Publisher
    pub = rospy.Publisher('/est_states', Estimation, queue_size=10)

    while not rospy.is_shutdown():

        state_est          = Estimation()
        state_est.phat     = phat
        state_est.qhat     = qhat
        state_est.rhat     = rhat
        state_est.Vahat    = Vahat
        state_est.pnhat    = pnhat
        state_est.pehat    = pehat
        state_est.hhat     = hhat
        state_est.chihat   = chihat
        state_est.vghat    = vghat
        state_est.phihat   = phihat
        state_est.thetahat = thetahat


        pub.publish(state_est)
        r1.sleep()

    rospy.loginfo("Shutting down in main")
    rospy.signal_shutdown(0)

if __name__ == "__main__":
	main()  

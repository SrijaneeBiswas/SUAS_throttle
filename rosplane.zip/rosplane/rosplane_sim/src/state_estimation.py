#!/usr/bin/env python


import rospy
import rospkg 
import numpy as np
import scipy.linalg as la
import utm
import math
from math import * 
from std_msgs.msg import String

from rosflight_msgs.msg import Airspeed
from rosflight_msgs.msg import GPS
from rosflight_msgs.msg import Barometer
from rosplane_msgs.msg import Estimation

from rosplane_msgs.msg import GPS_loc # custom message for calculating pn, pe wrt starting location
from sensor_msgs.msg import Imu

T=1.0/100.0
a=150
alpha_lpf = np.exp(-T*a)

############# Initializing variables ############

Ts          = 0.01 #Sampling Time

# for callback function 1
x_gyro_lpf = 0
y_gyro_lpf = 0
z_gyro_lpf = 0
phat       = 0
qhat       = 0
rhat       = 0

phi_num   = 0
phi_den   = 0
theta_num = 0

# for callback function 2
y_diff_press_lpf = 0
Vahat            = 0

# for callback function 3
y_static_press_lpf = 0
hhat               = 0

# for callback function 4
y_gps_n_lpf   = 0
y_gps_e_lpf   = 0
y_gps_chi_lpf = 0
y_gps_vg_lpf  = 0 

# initializing all the estimate states and associated P,Q,R matrices
phihat   = 0
thetahat = 0
pnhat    = 0
pehat    = 0
chihat   = 0
vghat    = 0
wnhat    = 0
wehat    = 0
psihat   = 0

# Sensor inputs
x_accel = 0
y_accel = 0
z_accel = 0
pn_lat  = 0
pe_lon  = 0
vg      = 0
chi     = 0
pn      = 0
pe      = 0

# Initializing other parameters
flag     = 0
gravity  = 9.8
rho      = 1.2682


xhat_gps = np.matrix([[pnhat],[pehat],[vghat],[chihat],[wnhat],[wehat],[psihat]])
Phat_gps = 0.001*np.matrix([[0.7*0.21,0,0,0,0,0,0],[0,0.7*0.21,0,0,0,0,0],[0,0,0.7*0.02,0,0,0,0],[0,0,0,0.7*0.02,0,0,0],[0,0,0,0,0.007,0,0],[0,0,0,0,0,0.007,0],[0,0,0,0,0,0,0.007]])
Q_gps    = 1.0/1000000.0*np.matrix([[10000,0,0,0,0,0,0],[0,10000,0,0,0,0,0],[0,0,10000,0,0,0,0],[0,0,0,10000,0,0,0],[0,0,0,0,10000,0,0,],[0,0,0,0,0,10000,0],[0,0,0,0,0,0,10000]])
R_gps    = np.matrix([[0.7*0.21,0,0,0,0,0],[0,0.7*0.21,0,0,0,0],[0,0,0.7*0.02,0,0,0],[0,0,0,0.7*0.02,0,0],[0,0,0,0,0.007,0],[0,0,0,0,0,0.007]])


###### Callback function to /fixedwing/imu/data topic #########

def callback(data): # function for estimating phat, qhat, rhat using LPF

    global x_gyro_lpf, y_gyro_lpf, z_gyro_lpf
    global phat, qhat, rhat
    global x_accel, y_accel, z_accel
    #global phihat, thetahat    

    x_accel    = data.linear_acceleration.x
    y_accel    = data.linear_acceleration.y
    z_accel    = data.linear_acceleration.z
    x_gyro     = data.angular_velocity.x
    y_gyro     = data.angular_velocity.y
    z_gyro     = data.angular_velocity.z
    
    x_gyro_lpf  = alpha_lpf*x_gyro_lpf  + (1-alpha_lpf)*x_gyro
    y_gyro_lpf  = alpha_lpf*y_gyro_lpf  + (1-alpha_lpf)*y_gyro
    z_gyro_lpf  = alpha_lpf*z_gyro_lpf  + (1-alpha_lpf)*z_gyro
   
    # When using attitude estimation, phi and theta are not estimated using LPF
    #phi_num     = alpha_lpf*phihat + (1-alpha_lpf)*y_accel
    #phi_den     = alpha_lpf*phihat + (1-alpha_lpf)*z_accel
    #theta_num   = alpha_lpf*thetahat + (1-alpha_lpf)*x_accel
    #phihat      = np.arctan2(phi_num,phi_den)
    #thetahat    = np.arcsin(theta_num/gravity)
    # ending phihat, thetahat calculation using LPF

    phat        = x_gyro_lpf
    qhat        = y_gyro_lpf
    rhat        = z_gyro_lpf

    return phat, qhat, rhat
    

###### Callback function to /fixedwing/airspeed topic #########

def callback2(data2): # function for estimating Vahat using LPF

    global y_diff_press_lpf
    global Vahat

    Va         = data2.velocity
    diff_press = data2.differential_pressure
    temp       = data2.temperature

    #y_diff_press_lpf = alpha_lpf*y_diff_press_lpf + (1-alpha_lpf)*diff_press
    #Vahat            = np.sqrt((2/rho)*y_diff_press_lpf)

    #Vahat = alpha_lpf*Vahat + (1-alpha_lpf)*Va    
    Vahat = Va
    return Vahat


###### Callback function to /fixedwing/gps topic ##############

def callback3(data3): # function for estimating pnhat, pehat, chihat, vghat

    global pn_lat, pe_lon
    global Y_gps

    pn_lat  = data3.pn
    pe_lon  = data3.pe
    vg      = data3.vg
    chi     = data3.chi

    Y_gps   = np.matrix([[pn_lat],[pe_lon],[vg],[chi],[0],[0]])
    
    return Y_gps


##### Callback function to /fixedwing/baro topic #########

def callback4(data4): # function to estimate hhat using LPF

    global y_static_press_lpf
    global hhat

    pd           = data4.altitude
    static_press = data4.pressure

    #y_static_press_lpf = alpha_lpf*y_static_press_lpf + (1-alpha_lpf)*static_press
    #hhat               = y_static_press_lpf/(rho*gravity)

    hhat = alpha_lpf*hhat + (1-alpha_lpf)*(-pd)

    return hhat
  

###### Calling Main function #############

def main():

    global chihat, psihat, vghat, wnhat, wehat, pnhat, pehat
    global Phat_gps, Q_gps, R_gps

    # Initialize the current node and publishing rate
    rospy.init_node('estimation', anonymous=True)
    r1 = rospy.Rate(50)

    # Define subscribers to the different sensors
    rospy.Subscriber('/fixedwing/imu/data', Imu, callback)
    rospy.Subscriber('/fixedwing/airspeed', Airspeed, callback2)
    rospy.Subscriber('/gps_loc', GPS_loc, callback3)
    rospy.Subscriber('/fixedwing/baro', Barometer, callback4)

    # Define the Publisher
    pub = rospy.Publisher('/est_states', Estimation, queue_size=10)

    while not rospy.is_shutdown():

        wnhat = -Vahat*np.cos(psihat) + vghat*np.cos(chihat)
        wehat = -Vahat*np.sin(psihat) + vghat*np.sin(chihat)

        if vghat <= 0:
            vghat = 0.001
        xhat_gps = np.matrix([[pnhat],[pehat],[vghat],[chihat],[wnhat],[wehat],[psihat]])

        for j in xrange(10):
            psidot = qhat*np.sin(phihat)/np.cos(thetahat) + rhat*np.cos(phihat)/np.cos(thetahat)
        
            chidot = np.divide(gravity*np.tan(phihat)*np.cos(chihat-psihat), vghat)
            vgdot  = np.divide((Vahat*np.cos(psihat)+wnhat)*(-Vahat*psidot*np.sin(psihat)) + (Vahat*np.sin(psihat)+wehat)*(Vahat*psidot*np.cos(psihat)), vghat)
        
            f_x_u = np.matrix([[vghat*np.cos(chihat)],[vghat*np.sin(chihat)],[vgdot],[chidot],[0],[0],[psidot]])


            vgdot_psi  = np.divide(-psidot*Vahat*(wnhat*np.cos(psihat)+wehat*np.sin(psihat)), vghat)
            chidot_vg  = np.divide(-gravity*np.tan(phihat)*np.cos(chihat-psihat), np.power(vghat, 2))
            chidot_chi = np.divide(-gravity*np.tan(phihat)*np.sin(chihat-psihat), vghat)
            chidot_psi = np.divide(gravity*np.tan(phihat)*np.sin(chihat-psihat), vghat)

            A_gps      = np.matrix([[0,0,np.cos(chihat),-vghat*np.sin(chihat),0,0,0],[0,0,np.sin(chihat),vghat*np.cos(chihat),0,0,0],[0,0,((Vahat*np.cos(psihat)+wnhat)*(-Vahat*psidot*np.sin(psihat))+(Vahat*np.sin(psihat)+wehat)*(Vahat*psidot*np.cos(psihat)))/(np.power(vghat,2)),0,-psidot*Vahat*sin(psihat)/vghat,psidot*Vahat*np.cos(psihat)/vghat,vgdot_psi],[0,0,chidot_vg,chidot_chi,0,0,chidot_psi],[0,0,0,0,0,0,0],[0,0,0,0,0,0,0],[0,0,0,0,0,0,0]])

            xhat_gps   = xhat_gps + (Ts/10.0)*f_x_u
            Phat_gps   = Phat_gps+Ts/10.0*(A_gps*Phat_gps + Phat_gps*np.transpose(A_gps) + Q_gps)

            pnhat  = xhat_gps.item(0)
            pehat  = xhat_gps.item(1)
            vghat  = xhat_gps.item(2)
            chihat = xhat_gps.item(3)
            wnhat  = xhat_gps.item(4)
            wehat  = xhat_gps.item(5)
            psihat = xhat_gps.item(6)

            while chihat > np.pi:
                chihat = chihat - 2*np.pi
            while chihat <= -np.pi:
                chihat = chihat + 2*np.pi

        if pn_lat != pe_lon:
            h_x_u_gps = np.matrix([[pnhat],[pehat],[vghat],[chihat],[Vahat*np.cos(psihat)+wnhat-vghat*np.cos(chihat)],[Vahat*np.sin(psihat)+wehat-vghat*np.sin(chihat)]]) 

            H_gps = np.matrix([[1,0,0,0,0,0,0],[0,1,0,0,0,0,0],[0,0,1,0,0,0,0],[0,0,0,1,0,0,0],[0,0,-np.cos(chihat),vghat*np.sin(chihat),1,0,-Vahat*np.sin(psihat)],[0,0,-np.sin(chihat),-vghat*np.cos(chihat),0,1,Vahat*np.cos(psihat)]])


            L_gps = Phat_gps*np.transpose(H_gps)*np.linalg.inv(R_gps+H_gps*Phat_gps*np.transpose(H_gps))

            l1 = len(L_gps*H_gps)
            Phat_gps = (np.identity(l1)-L_gps*H_gps)*Phat_gps
            xhat_gps = xhat_gps + L_gps*(Y_gps-h_x_u_gps)

        pnhat  = xhat_gps.item(0)
        pehat  = xhat_gps.item(1)
        vghat  = xhat_gps.item(2)
        chihat = xhat_gps.item(3)
        wnhat  = xhat_gps.item(4)
        wehat  = xhat_gps.item(5)
        psihat = xhat_gps.item(6)

        while chihat > np.pi:
            chihat = chihat - 2*np.pi
        while chihat <= -np.pi:
            chihat = chihat + 2*np.pi

        state_est          = Estimation()
        state_est.phat     = phat
        state_est.qhat     = qhat
        state_est.rhat     = rhat
        state_est.Vahat    = Vahat
        state_est.pnhat    = pnhat
        state_est.pehat    = pehat
        state_est.hhat     = hhat
        state_est.chihat   = chihat
        state_est.vghat    = vghat
        state_est.phihat   = phihat
        state_est.thetahat = thetahat

        
        pub.publish(state_est)
        r1.sleep()

    rospy.loginfo("Shutting down in main")
    rospy.signal_shutdown(0)

if __name__ == "__main__":
	main()  

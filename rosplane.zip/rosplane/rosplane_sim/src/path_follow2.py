#!/usr/bin/env python

import sys
import rospy
import math
import numpy as np

from rosplane_msgs.msg import State
from rosplane_msgs.msg import follow_out
from rosplane_msgs.msg import Estimation

# Initializing
pn  = 0.0
pe  = 0.0
chi = 0.0

# Callback for true states
def callback(data):
    global pn, pe, chi
    pn  = data.position[0]
    pe  = data.position[1]
    chi = data.chi

def callback2(data2):
    global pn, pe, chi

    pn = data2.pnhat
    pe = data2.pehat
    chi = data2.chihat

# The math node
def follow_func():
    #global pn, pe, chi

    pi = math.pi

    # Values for straight line
    r_path   = np.array([0.0, 0.0, -100.0])
    q_temp   = np.array([-0.5, -1.0, -0.05])
    q_path_0 = q_temp.item(0)/np.sqrt(q_temp.item(0)**2.0 + q_temp.item(1)**2.0 + q_temp.item(2)**2.0)
    q_path_1 = q_temp.item(1)/np.sqrt(q_temp.item(0)**2.0 + q_temp.item(1)**2.0 + q_temp.item(2)**2.0)
    q_path_2 = q_temp.item(2)/np.sqrt(q_temp.item(0)**2.0 + q_temp.item(1)**2.0 + q_temp.item(2)**2.0)
    q_path   = np.array([q_path_0, q_path_1, q_path_2])

    # Values for circular trajectory
    c_circle = np.array([1.0, 1.0, -100.0])
    rho      = 400.0
    lam      = 1.0

    # Straight (0) or Circular (1)
    path_type = 1

    # Tuning parameters
    k_path   = 1.0
    chi_inf  = 22.5*pi/180.0
    k_circle = 5.0

    if (path_type == 0): # Straight

        ep = q_path - r_path

        k_vec = np.array([0.0, 0.0, 1.0])

        n_low = np.cross(q_path, k_vec)

        n_0 = n_low.item(0)/np.sqrt(n_low.item(0)**2.0 + n_low.item(1)**2.0 + n_low.item(2)**2.0)
        n_1 = n_low.item(1)/np.sqrt(n_low.item(0)**2.0 + n_low.item(1)**2.0 + n_low.item(2)**2.0)
        n_2 = n_low.item(2)/np.sqrt(n_low.item(0)**2.0 + n_low.item(1)**2.0 + n_low.item(2)**2.0)

        n_path = np.array([n_0, n_1, n_2])

        s_path = ep - np.dot(ep, n_path) * n_path

        chi_q = np.arctan2(q_path.item(1), q_path.item(0))
        while ((chi_q - chi) < -pi):
            chi_q = chi_q + 2.0*pi
        while ((chi_q - chi) > pi):
            chi_q = chi_q - 2.0*pi

        e_p_y = -np.sin(chi_q) * (pn - r_path.item(0)) + np.cos(chi_q) * (pe - r_path.item(1))
        
        chi_c = chi_q - chi_inf * 2.0/pi * np.arctan(k_path*e_p_y)
        while (chi_c < -pi):
            chi_c = chi_c + 2.0*pi
        while (chi_c > pi):
            chi_c = chi_c - 2.0*pi

        h_c   = -r_path.item(2) + np.sqrt(s_path.item(0)**2.0 + s_path.item(1)**2.0) * q_path.item(2)/np.sqrt(q_path.item(0)**2.0 + q_path.item(1)**2.0)

    elif (path_type == 1):
        d_circle = np.sqrt((pn - c_circle.item(0))**2.0 + (pe - c_circle.item(1))**2.0)

        phu = np.arctan2((pe - c_circle.item(1)), (pn - c_circle.item(0)))
        while ((phu - chi) < -pi):
            phu = phu + 2.0*pi
        while ((phu - chi) > pi):
            phu = phu - 2.0*pi

        chi_c = phu + lam * (pi/2.0 + np.arctan(k_circle*(d_circle -rho)/rho))
        while (chi_c < -pi):
            chi_c = chi_c + 2.0*pi
        while (chi_c > pi):
            chi_c = chi_c - 2.0*pi
        h_c   = -c_circle.item(2)


    fol_array = np.array([chi_c, h_c])
    return(fol_array)

# Publishing and subscribing
def main():

    # Tells rospy the name of the code to com. with ROS master
    rospy.init_node('trajectory',anonymous=True)

    # Expected loop frequency per second
    rate=rospy.Rate(50)

    # Subscribing to TRUE states
    #sub = rospy.Subscriber('/fixedwing/truth', State, callback)
    rospy.Subscriber('/est_states', Estimation, callback2)

    # Publishing information
    pub = rospy.Publisher('/follow_out', follow_out, queue_size=10)

    while not rospy.is_shutdown():

        fol_out = follow_func()
        command = follow_out()

        command.chi_c = fol_out.item(0)
        command.h_c   = fol_out.item(1)

        pub.publish(command)

        rate.sleep()



if __name__ == "__main__":
	main()

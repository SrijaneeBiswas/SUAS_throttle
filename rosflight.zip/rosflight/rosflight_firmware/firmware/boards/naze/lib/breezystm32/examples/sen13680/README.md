# sen13680: Read distances from Sparkfun SEN13680 LIDAR-Lite v2 I<sup>2</sup>C sensor

Don't forget to supply external power to the board!

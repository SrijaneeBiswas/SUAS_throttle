# i2csniff: Detect and report I<sup>2</sup>C devices 

Don't forget to supply external power for external sensors (like MB1242 sonar)!

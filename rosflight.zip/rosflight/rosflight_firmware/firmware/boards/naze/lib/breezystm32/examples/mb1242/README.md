# mb1242: Read distances from MaxBotix MB1242 ultrasonic I<sup>2</sup>C sensor

Don't forget to supply external power to the board!
